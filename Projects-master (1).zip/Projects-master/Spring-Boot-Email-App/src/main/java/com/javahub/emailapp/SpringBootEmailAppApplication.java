package com.javahub.emailapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmailAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmailAppApplication.class, args);
	}

}
