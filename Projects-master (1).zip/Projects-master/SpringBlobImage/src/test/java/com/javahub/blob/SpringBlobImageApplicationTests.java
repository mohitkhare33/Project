package com.javahub.blob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBlobImageApplicationTests {

	@Test
	void contextLoads() {
	}

}
