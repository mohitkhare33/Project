package com.javahub.blob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBlobImageApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBlobImageApplication.class, args);
	}

}
